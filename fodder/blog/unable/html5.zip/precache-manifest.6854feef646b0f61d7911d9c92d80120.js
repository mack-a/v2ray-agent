self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "560520737bf1eae042e09b2340ec40f5",
    "url": "03ab1ccebc1df96da5ee.worker.js"
  },
  {
    "revision": "0004e134d20967c121d8",
    "url": "css/app.893c7cfa.css"
  },
  {
    "revision": "c15d693f0a534d80d850",
    "url": "css/chunk-vendors.8cf7dd44.css"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "52a3eff4cd6daf1f6e33e40567e72e62",
    "url": "index.html"
  },
  {
    "revision": "0004e134d20967c121d8",
    "url": "js/app.319aaba4.js"
  },
  {
    "revision": "c15d693f0a534d80d850",
    "url": "js/chunk-vendors.56f18896.js"
  },
  {
    "revision": "28f3e13ec88073aa1b85b7d66358f613",
    "url": "manifest.json"
  },
  {
    "revision": "523b1a2eae8cb533fa6bd73831308f09",
    "url": "static/kgm.mask"
  }
]);